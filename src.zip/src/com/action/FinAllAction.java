package com.action;

public class FinAllAction {

    public String financialallocation(){

        return "financialallocation";
    }
}
